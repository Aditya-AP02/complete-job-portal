# Job-Portal
I create the Job portal website using html, css, and Javascript. in this website the user looking for job and user search any company name then it goes to official website of searching company
